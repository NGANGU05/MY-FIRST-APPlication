
package registration2;


 

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedList;

public class pa {
    
    public static final String SENTINAL = "888888888888";

    public pa() {
        

   
        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        

        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        panel.setLayout(null);
        
        JLabel UserNameLabel =  new JLabel("UserName");
        UserNameLabel.setBounds(10,20,80,25);
        panel.add(UserNameLabel);

        JTextField Text = new JTextField();
        Text.setBounds(100,20,265,25);
        panel.add(Text);

        JLabel pLabel = new JLabel("Password");
        pLabel.setBounds(10,90,180,40);
        panel.add(pLabel);
          
        JPasswordField passwordText = new JPasswordField();
        passwordText.setBounds(80,100,300,25);
        panel.add(passwordText);
        JButton button= new JButton("START");
        button.setBounds(20, 180, 200, 25);
        
        frame.setVisible(true);
        frame.add(button);
        panel.add(button);
        
        
        
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                String userName = Text.getText();
                String password = new String(passwordText.getPassword());
                
                GETUSER(userName, password);
                new bonsoir();
            }
        } );
                
                
    }
    
    
    public static boolean checkPasswordComplexity(JPasswordField password)
            
    {
            String passwordText = new String(password.getPassword());
            //passwordText = passwordText.getText();
            boolean isValid = false;
            boolean lengthValid = false;
            boolean UppercaseValid = false;
            boolean numbersValid = false;
            boolean lowerValid = false;
            boolean specialChartsValid = false;
            if (passwordText.length() >=8  )
            {
                    lengthValid = true;;
                  
            }
            String upper = "(.*[A-Z].*)";
            if (passwordText.matches(upper ))
            {
                    UppercaseValid = true;
                    System.out.println("upp");
            }
            String lower = "(.*[a-z].*)";
            if (passwordText.matches(lower ))
            {
                    lowerValid = true;
                    System.out.println("low");
            }
            String num = "(.*[0-9].*)";
            if (passwordText.matches(num ))
            {
                    numbersValid = true;
                    System.out.println("num");
            }
            String special = "(.*[!,^,*,(,),-,_,=,+,`,~,?,/,:,@,#,$,%].*$)";
            if (passwordText.matches(special ))
            {
                    specialChartsValid= true;
                    System.out.println("cha");
            }
            
            if (lengthValid == true && UppercaseValid == true && numbersValid == true && lowerValid == true && specialChartsValid == true ){
                System.out.println("Password is successfully captured ");
                
                isValid = true;
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted ,please ensure that the password contains at least 8 characters , a capital letter , number and a special charater click ok to resart","Password",0);
            }
            
            return isValid ; 
    }
    
    private boolean CheckUser(JTextField usernameText) {
        boolean isValid = false;
        String Username = usernameText.getText();
        if (Username.length()<= 5 && Username.contains("_") ){
            isValid = true ;
            System.out.println("Username is successfully ");



        }else{ 


            JOptionPane.showMessageDialog(null,"Username is not formatted please ensure that you username contains an underscaore and is not more than 5 characters); ");
            isValid = false;
        }
        return isValid;
    }
    
    public static void GETUSER(String userName, String password){
        String account;
        String name;
        String lastName;
        boolean found = false;
        LinkedList<String> info = new LinkedList<String>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("accounts.txt"));
            while ((account = reader.readLine()) != null) {
                if (account.equals(userName) || found){
                    found = true;

                    // these are the lines between the user 
                    if (account.equals(SENTINAL)){
                        found = false;
                    }else {
                        info.add(account);
                    }
                }
            }

        reader.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }

        if (!info.isEmpty()){
            if (password.equals(info.get(2))) {
                name = info.get(1);

                String outputMessage = "Welcome " + name + " its great to see you again.";
                JOptionPane.showMessageDialog(null, outputMessage);
            }else{
                JOptionPane.showMessageDialog(null, " you input a wrong Username or password,please try again");
            }
        }else{
            JOptionPane.showMessageDialog(null, "your accounts is not registred, please try again");
        }
        
    }

    static class app {

        public app() {
        }
    }
    
    


}




























































































