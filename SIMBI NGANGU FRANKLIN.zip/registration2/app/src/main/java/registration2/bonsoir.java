
package registration2;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class bonsoir {

    public bonsoir() {
        
          JFrame frame = new JFrame("Welcome to EasyKanban");
        frame.setBounds(0, 0, 900, 900);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(Color.black);
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBounds(0,0,800,100);
        // here we are giving the cashier option to chose , we try to use JMenu .
        JMenu menu = new JMenu("Welcome to EasyKanban");
        JMenuItem makeSale = new JMenuItem("BEGIN");
        makeSale.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                new partir();
                
                
            } 
        });
        menu.add(makeSale);
        
        JMenuItem printReport = new JMenuItem("PRINT YOUR  REPORT");
        printReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                new Report();
                
                        }
        });
        menu.add(printReport);
        
        JMenuItem quit = new JMenuItem("QUIT");
        quit.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
               
                 JOptionPane.showMessageDialog(null,  " thank you for using our program");
                 
            } 
        });
        menu.add(quit);
        
        menuBar.add(menu);
        
        frame.add(menuBar);
        frame.setVisible(true);
      
        

    }
    

}
    
          
        
        