
package registration2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Flranklin
 */
public class partirTest {
    Task my;
    public partirTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        my = new Task  ();
    }
    
    @AfterEach
    public void tearDown() {
        my=null;
    }

    @Test
    public void testTaskNum() {
        boolean n = my.myboolean(true);
        assertEquals(true,n);
    }

    @Test
    public void testTaskMaker() {
        String l="ffff";
        String m=my.mystring2(l);
        assertEquals(l,m);
    }
    
   
}
