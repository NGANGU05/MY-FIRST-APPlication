
package rc_poe;


import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Report {

    public Report() {
        
        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        

        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        panel.setLayout(null);
        frame.getContentPane().setBackground(Color.RED);
                frame.setVisible(true);
         
        
        
        
        
         JOptionPane.showMessageDialog(null, " Coming Soon  ");
        
    }
}
