
package rc_poe;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import javax.swing.JPanel;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedList;

import javax.swing.*;

public class WOLA  {
    final static String SENTINAL = "TheEndOfUserInformation";


    public static void main(String[] args) {
         JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        
       


        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
         // so we do consider this page as our welcome page
        panel.setLayout(null);
        frame.getContentPane().setBackground(Color.black);
     
        JLabel LastName =new JLabel();
        LastName.setBounds(50,100,75,25);
        LastName.setText("Last Name");
        frame.add( LastName);
        
        JTextField fieldLastName =new JTextField();
        fieldLastName.setBounds(125,100,150,25);
         frame.add(fieldLastName );
        

        JLabel FirstName =new JLabel();
        FirstName.setBounds(50,50,75,25);
        FirstName.setText("First Name"); 
        frame.add(FirstName);

        JTextField TtxtfieldFirstName =new JTextField();
        TtxtfieldFirstName.setBounds(125,50,150,25);
        frame.add(TtxtfieldFirstName);
        JLabel myUsername =new JLabel();
        myUsername.setBounds(50,150,75,25);
        myUsername.setText("Username");
        frame.add(myUsername);

        JTextField TtxtfieldUserID =new JTextField();
        TtxtfieldUserID.setBounds(125,150,150,25);
        frame.add(TtxtfieldUserID);

        JLabel myPassword =new JLabel();
        myPassword.setBounds(50,200,75,25);
        myPassword.setText("Password");
        frame.add(myPassword);
        

        JPasswordField TtxtfieldPassword = new JPasswordField();
        TtxtfieldPassword.setBounds(125,200,150,25);
        frame.add(TtxtfieldPassword);
        
        JButton GoToNextPage= new JButton("Login");
        GoToNextPage.setBounds(90,300,100,25);
              
        
        
        GoToNextPage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                new Login();
                
            }

        }); 
        
         frame.add(GoToNextPage);
        
        JButton Login= new JButton("Register");
        Login.setBounds(10,250,100,25);

        Login.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                
                boolean usernameValid = CheckUsername( TtxtfieldUserID );
                boolean passwordValid = checkPasswordComplexity(TtxtfieldPassword);
            
                if (usernameValid == true && passwordValid == true ){
                    String userName = TtxtfieldUserID .getText();
                    String password = new String(TtxtfieldPassword.getPassword());
                    if (CheckUsername(TtxtfieldUserID ) && checkPasswordComplexity(TtxtfieldPassword) )
                        StringregisterUser(userName, password, TtxtfieldFirstName.getText());
                    new Login();                    
                }
                
            }
        });
        
        

      
        
    
        panel.add(Login);

        frame.add(panel);
        
        frame.setVisible(true);  
        
  
    }
    
    private static boolean CheckUsername(JTextField usernameText) {
        boolean isValid = false;
        String Username = usernameText.getText();
        if (Username.length()<= 5 && Username.contains("_") ){
            isValid = true ;
            System.out.println("Username is successfully captured" );
           

        }else{ 
            JOptionPane.showMessageDialog(null,"Username is not formatted please ensure that you username contains an underscaore and is not more than 5 characters ");
            isValid = false;
        }
        return isValid;
    }
    
    public static boolean checkPasswordComplexity(JPasswordField password)
            
    {
        String passwordText = new String(password.getPassword());
        //passwordText = passwordText.getText();
        boolean isValid = false;
        boolean lengthValid = false;
        boolean UppercaseValid = false;
        boolean numbersValid = false;
        boolean lowerValid = false;
        boolean specialChartsValid = false;
        if (passwordText.length() >=8  )
            {
                    lengthValid = true;;
              
            }
            String upperCaseChars = "(.*[A-Z].*)";
            if (passwordText.matches(upperCaseChars ))
            {
                    UppercaseValid = true;
             
            }
            String lowerCaseChars = "(.*[a-z].*)";
            if (passwordText.matches(lowerCaseChars ))
            {
                    lowerValid = true;
              
            }
            String numbers = "(.*[0-9].*)";
            if (passwordText.matches(numbers ))
            {
                    numbersValid = true;
                
            }
            String specialChars = "(.*[!,^,*,(,),-,_,=,+,`,~,?,/,:,@,#,$,%].*$)";
            if (passwordText.matches(specialChars ))
            {
                    specialChartsValid= true;
                
            }
            
            if (lengthValid == true && UppercaseValid == true && numbersValid == true && lowerValid == true && specialChartsValid == true ){
                System.out.println("Password is successfully captured ");
                
                isValid = true;
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted ,please ensure that the password contains at least 8 characters , a capital letter , number and a special charater click ok to resart","Password",0);
            }

        return isValid ; 
    }
    
    public static void StringregisterUser(String userName, String password, String nameAndSurname) {
        
        Boolean finishedReading = false;
        Boolean finishedWiting = false;

        LinkedList<String> previousInfo = new LinkedList<String>();

        // Ensuring that the old infomaton isn't lost
        try {
            BufferedReader reader = new BufferedReader(new FileReader("accounts.txt"));
            String data;
            
            while ((data = reader.readLine()) != null) {
                previousInfo.add(data);
            }
            reader.close();
            finishedReading = true;

        }catch (Exception e) {
            System.out.println("Error occured while trying to read from database");
        }

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("accounts.txt"));
            for (String line : previousInfo) {
                writer.write(line);
                writer.write("\n");
            }
            // write new data to file:
            writer.write(userName);
            writer.write("\n" + nameAndSurname);
            writer.write("\n" + password);
            writer.write("\n" + SENTINAL);

            writer.close();
            finishedWiting = true;
        
        } catch (Exception e) {
            System.out.println("Error occured while trying to write to database");
            e.printStackTrace();
                  
        }

    }

    

    }


        
        
    



       