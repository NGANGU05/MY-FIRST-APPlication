
package loginform;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import static loginform.RegistrationForm.main;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedList;


/**
 *
 * @author Flranklin
 */
public class Login  {
    
    public static final String SENTINAL = "999999999999";

    public Login() {
        

   
        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        

        frame.setSize(700,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        panel.setLayout(null);
        
        JLabel UserNameLabel =  new JLabel("UserName");
        UserNameLabel.setBounds(10,20,80,25);
        panel.add(UserNameLabel);

        JTextField usernameText = new JTextField();
        usernameText.setBounds(100,20,265,25);
        panel.add(usernameText);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(10,90,180,40);
        panel.add(passwordLabel);
          
        JPasswordField passwordText = new JPasswordField();
        passwordText.setBounds(80,100,300,25);
        panel.add(passwordText);
        JButton Login = new JButton("Login");
        Login.setBounds(20, 180, 200, 25);
        
        frame.setVisible(true);
        frame.add(Login);
        panel.add(Login);
        
        
        
        Login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                String userName = usernameText.getText();
                String password = new String(passwordText.getPassword());
                loginUser(userName, password);
            }
        } );
                
                
    }
    
    
    public static boolean checkPasswordComplexity(JPasswordField password)
            
    {
            String passwordText = new String(password.getPassword());
            //passwordText = passwordText.getText();
            boolean isValid = false;
            boolean lengthValid = false;
            boolean UppercaseValid = false;
            boolean numbersValid = false;
            boolean lowerValid = false;
            boolean specialChartsValid = false;
            if (passwordText.length() >=8  )
            {
                    lengthValid = true;;
                  
            }
            String upperCaseChars = "(.*[A-Z].*)";
            if (passwordText.matches(upperCaseChars ))
            {
                    UppercaseValid = true;
                    System.out.println("upp");
            }
            String lowerCaseChars = "(.*[a-z].*)";
            if (passwordText.matches(lowerCaseChars ))
            {
                    lowerValid = true;
                    System.out.println("low");
            }
            String numbers = "(.*[0-9].*)";
            if (passwordText.matches(numbers ))
            {
                    numbersValid = true;
                    System.out.println("num");
            }
            String specialChars = "(.*[!,^,*,(,),-,_,=,+,`,~,?,/,:,@,#,$,%].*$)";
            if (passwordText.matches(specialChars ))
            {
                    specialChartsValid= true;
                    System.out.println("cha");
            }
            
            if (lengthValid == true && UppercaseValid == true && numbersValid == true && lowerValid == true && specialChartsValid == true ){
                System.out.println("Password is successfully captured ");
                JOptionPane.showMessageDialog(null, "Congratulation press ok to continue");
                isValid = true;
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted ,please ensure that the password contains at least 8 characters , a capital letter , number and a special charater click ok to resart","Password",0);
            }
            
            return isValid ; 
    }
    
    private boolean CheckUsername(JTextField usernameText) {
        boolean isValid = false;
        String Username = usernameText.getText();
        if (Username.length()<= 5 && Username.contains("_") ){
            isValid = true ;
            System.out.println("Username is successfully captured");



        }else{ 


            JOptionPane.showMessageDialog(null,"Username is not formatted please ensure that you username contains an underscaore and is not more than 5 characters); ");
            isValid = false;
        }
        return isValid;
    }
    
    public static void loginUser(String userName, String password){
        String account;
        String name;
        String lastName;
        boolean found = false;
        LinkedList<String> info = new LinkedList<String>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("accounts.txt"));
            while ((account = reader.readLine()) != null) {
                if (account.equals(userName) || found){
                    found = true;

                    // these are the lines between the user 
                    if (account.equals(SENTINAL)){
                        found = false;
                    }else {
                        info.add(account);
                    }
                }
            }

        reader.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }

        if (!info.isEmpty()){
            if (password.equals(info.get(2))) {
                name = info.get(1);

                String outputMessage = "Welcome " + name + " its great to see you again.";
                JOptionPane.showMessageDialog(null, outputMessage);
            }else{
                JOptionPane.showMessageDialog(null, "Username or password is incorrect,please try again");
            }
        }else{
            JOptionPane.showMessageDialog(null, "No accounts have been registered yet, please try again");
        }
        
    }
    
    


}




























































































