/*
 */
package loginform;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedList;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


/**
 *
 * @author Flranklin
 */
public class RegistrationForm {
    
    public static final String SENTINAL = "999999999999";

    public static void main (String[] args) {

        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        

        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        panel.setLayout(null);
        
        JLabel UserNameLabel =  new JLabel("UserName");
        UserNameLabel.setBounds(10,20,80,25);
        panel.add(UserNameLabel);

        JTextField usernameText = new JTextField();
        usernameText.setBounds(100,20,265,25);
        panel.add(usernameText);

        JLabel firstNameLabel = new JLabel("FirstName amd LastName");
        firstNameLabel.setBounds(10,50,600,50);
        panel.add(firstNameLabel);
         
        JTextField firstNameText = new  JTextField();
        firstNameText.setBounds(160,60,400,25);
        panel.add(firstNameText);

        JLabel lastNamelabel = new JLabel("LastName");
        UserNameLabel.setBounds(10,20,80,25);
        panel.add(UserNameLabel);

        JTextField lastNameText = new JTextField();
        lastNameText.setBounds(100,20,265,25);
        panel.add(lastNameText);
              
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(10,90,180,40);
        panel.add(passwordLabel);
          
        JPasswordField passwordText = new JPasswordField();
        passwordText.setBounds(80,100,300,25);
        panel.add(passwordText);
        
        
        JButton GoToNextPage= new JButton("Login");
        GoToNextPage.setBounds(10,180,100,25);
        
        
        GoToNextPage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                new Login();
            }

        }); 
        
        frame.add(GoToNextPage);
        
        JButton Login= new JButton("Register");
        Login.setBounds(10,130,100,25);

        Login.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                
                boolean usernameValid = CheckUsername( usernameText);
                boolean passwordValid = checkPasswordComplexity(passwordText);
            
                if (usernameValid == true && passwordValid == true ){
                    String userName = usernameText.getText();
                    String password = new String(passwordText.getPassword());
                    if (CheckUsername(usernameText) && checkPasswordComplexity(passwordText) )
                        StringregisterUser(userName, password, firstNameText.getText());
                    new Login();                    
                }
                
            }
        });
        
        panel.add(Login);

        frame.add(panel);
        
        frame.setVisible(true);        
    }
    
    private static boolean CheckUsername(JTextField usernameText) {
        boolean isValid = false;
        String Username = usernameText.getText();
        if (Username.length()<= 5 && Username.contains("_") ){
            isValid = true ;
            System.out.println("Username is successfully captured" );
            JOptionPane.showMessageDialog(null, "username successfully captured");

        }else{ 
            JOptionPane.showMessageDialog(null,"Username is not formatted please ensure that you username contains an underscaore and is not more than 5 characters ");
            isValid = false;
        }
        return isValid;
    }
    
    public static boolean checkPasswordComplexity(JPasswordField password)
            
    {
        String passwordText = new String(password.getPassword());
        //passwordText = passwordText.getText();
        boolean isValid = false;
        boolean lengthValid = false;
        boolean UppercaseValid = false;
        boolean numbersValid = false;
        boolean lowerValid = false;
        boolean specialChartsValid = false;
        if (passwordText.length() >=8  )
            {
                    lengthValid = true;;
              
            }
            String upperCaseChars = "(.*[A-Z].*)";
            if (passwordText.matches(upperCaseChars ))
            {
                    UppercaseValid = true;
             
            }
            String lowerCaseChars = "(.*[a-z].*)";
            if (passwordText.matches(lowerCaseChars ))
            {
                    lowerValid = true;
              
            }
            String numbers = "(.*[0-9].*)";
            if (passwordText.matches(numbers ))
            {
                    numbersValid = true;
                
            }
            String specialChars = "(.*[!,^,*,(,),-,_,=,+,`,~,?,/,:,@,#,$,%].*$)";
            if (passwordText.matches(specialChars ))
            {
                    specialChartsValid= true;
                
            }
            
            if (lengthValid == true && UppercaseValid == true && numbersValid == true && lowerValid == true && specialChartsValid == true ){
                System.out.println("Password is successfully captured ");
                JOptionPane.showMessageDialog(null, "Password capatured successfully");
                isValid = true;
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted ,please ensure that the password contains at least 8 characters , a capital letter , number and a special charater click ok to resart","Password",0);
            }

        return isValid ; 
    }
    
    public static void StringregisterUser(String userName, String password, String nameAndSurname) {
        
        Boolean finishedReading = false;
        Boolean finishedWiting = false;

        LinkedList<String> previousInfo = new LinkedList<String>();

        // Ensuring that the old infomaton isn't lost
        try {
            BufferedReader reader = new BufferedReader(new FileReader("accounts.txt"));
            String data;
            
            while ((data = reader.readLine()) != null) {
                previousInfo.add(data);
            }
            reader.close();
            finishedReading = true;

        }catch (Exception e) {
            System.out.println("Error occured while trying to read from database");
        }

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("accounts.txt"));
            for (String line : previousInfo) {
                writer.write(line);
                writer.write("\n");
            }
            // write new data to file:
            writer.write(userName);
            writer.write("\n" + nameAndSurname);
            writer.write("\n" + password);
            writer.write("\n" + SENTINAL);

            writer.close();
            finishedWiting = true;
        
        } catch (Exception e) {
            System.out.println("Error occured while trying to write to database");
            e.printStackTrace();
        }

    }
    

   

}
        
        
    




 
 