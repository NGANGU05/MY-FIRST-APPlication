/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PoePart1;

/**
 *
 * @author PRISCA
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class Login implements ActionListener {
    private static JLabel userlabel;
    private static JTextField usertext;
    private static JLabel passwordlabel;
    private static JTextField passwordtext;
    private static JButton button;
    private static JLabel success;

    private WelcomePage welcomePage = new WelcomePage();

    public static void main () {
        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        frame.setSize(350,400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setTitle("Login");
        panel.setLayout(null);
        userlabel=new JLabel();
        userlabel.setText("user");
        userlabel.setBounds(10, 20,80,25);
        panel.add(userlabel);
        usertext= new JTextField(20);
        usertext.setBounds(100, 20, 165, 25);
        panel.add(usertext);
        passwordlabel= new JLabel();
        passwordlabel.setText("password");
        passwordlabel.setBounds(10, 50, 80, 25);
        panel.add(passwordlabel);
        passwordtext= new JTextField(20);
        passwordtext.setBounds(100,50,165,25);
        panel.add(passwordtext);
        button= new JButton("Login");
        button.setBounds(10,80,80,25);
        button.addActionListener(new Login());
        panel.add(button);
        success= new JLabel();
        success.setBounds(10,110,300,25);
        panel.add(success);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String User = usertext.getText();
        String Password = passwordtext.getText();
        System.out.println(User + " " + Password);
        
        if(User.length()<=10&& User.contains("_")&&Password.length()>=8){
            if(Pattern.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*)(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z0-9@$!%*?&]{8,}$", Password)){
                JOptionPane.showMessageDialog(null,  "Username successfully captured Password successfully captured");
                success.setText("Login successful!");
                JOptionPane.showMessageDialog(null, "Login successful");
                welcomePage.showWelcomePage();
            }
            else {
                JOptionPane.showMessageDialog(null,"Wrong password");
            }
        }
        else if(User.length()<4&&!User.contains("_")){
            JOptionPane.showMessageDialog(null,"Wrong username");
        }
        else if (Password.length()<=8){
            JOptionPane.showMessageDialog(null,"Wrong password");
        }
        else{
            JOptionPane.showMessageDialog(null,"Wrong username and password");
        }
    }
}

class WelcomePage {
    private final JPanel panel;
    private final JFrame frame;
    private final JLabel welcome;
    private final JButton welcomeButton;

    public WelcomePage() {
        panel = new JPanel();
        frame = new JFrame();
        frame.setSize(350,400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setTitle("Welcome");
        panel.setLayout(null);
        welcome = new JLabel("Welcome to Easy Kanban!");
        welcome.setBounds(10, 20, 80, 25);
        panel.add(welcome);
        
        welcomeButton = new JButton("Add Task");
        welcomeButton.setBounds(10, 50, 120, 25);
        welcomeButton.addActionListener(new ActionListener() {
            
            
            @Override
            public void actionPerformed(ActionEvent e) {
               taskpage app = new taskpage();
               app.main();
            }

           
        });
        panel.add(welcomeButton);
    }

    public void showWelcomePage() {
        frame.setVisible(true);
    }

    public void disposeFrame() {
        frame.dispose();
}
}