/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PoePart1;

/**
 *
 * @author PRISCA
 */
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.regex.Pattern;

class Registration implements ActionListener {
    private static JLabel namelabel;
    private static JTextField nametext;
    private static JLabel surnamelabel;
    private static JTextField surnametext;
    private static JButton button;
    private static JLabel success;
    private static JLabel userlabel;
    private static JTextField usertext;
    private static JLabel passwordlabel;
    private static JTextField passwordtext;
    
    
    public void main(){
        JPanel panel= new JPanel();
        JFrame frame= new JFrame();
        frame.setTitle("Registration");
        frame.setSize(356,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.add(panel);
        panel.setLayout(null);
        
        namelabel= new JLabel();
        namelabel.setText("First name");
        namelabel.setBounds(10, 20, 80, 25);
        panel.add(namelabel);
        
        nametext= new JTextField(20);
        nametext.setBounds(100,20,165,25);
        panel.add(nametext);
        
        surnamelabel= new JLabel();
        surnamelabel.setText("Last name");
        surnamelabel.setBounds(10,50,80,25);
        panel.add(surnamelabel);
        
        surnametext= new JTextField(20);
        surnametext.setBounds(100,50,165,25);
        panel.add(surnametext);
        
        userlabel= new JLabel();
        userlabel.setText("UserName");
        userlabel.setBounds(10,80,80,25);
        panel.add(userlabel);
        
        usertext = new JTextField(20);
        usertext.setBounds(100,80,165,25);
        panel.add(usertext);
        
        passwordlabel= new JLabel();
        passwordlabel.setText("Password");
        passwordlabel.setBounds(10,110,80,25);
        panel.add(passwordlabel);
        
        passwordtext= new JTextField();
        passwordtext.setBounds(100,111,165,25);
        panel.add(passwordtext );
        
        button= new JButton("button");
         button.addActionListener( new Registration());
        button.setBounds(10,140,80,25);
        panel.add(button);
        
        
        success= new JLabel();
       success.setBounds(10,170,300,25);
       panel.add(success);
        
        
         
        
    }

   @Override
    public void actionPerformed(ActionEvent e) {
       String name= nametext.getText();
       String surme=surnametext.getText();
       String user = usertext.getText();
       String password =passwordtext.getText();
      
          
       if(user.length()<=5 && user.contains("_")&&password.length()>=8){
          
            if(Pattern.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*)(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z0-9@$!%*?&]{8,}$",password))
           {
                success.setText("succeful!");
                JOptionPane.showMessageDialog(null,  "Username successfully captured Password successfully captured");
                JOptionPane.showMessageDialog(null,user+","+password);
                Login.main();
              
           }
           else{
               JOptionPane.showMessageDialog(null,"Password missing something !");
           }
       
       }
       else if (!user.contains("_")){
           JOptionPane.showMessageDialog(null,"Username is not correctly formatted please ensure thatyour usernamecontains an underscore and is nomore than 5characters in length");
           
       }
       else if (password.length()<8){
            JOptionPane.showMessageDialog(null,"Password is no correctly formatted please ensure that the password contains at least 8 characters a capital letter a number and special character");
       }
       else{
            JOptionPane.showMessageDialog(null,"Wrong username and password");  
       }
    } 
}
    