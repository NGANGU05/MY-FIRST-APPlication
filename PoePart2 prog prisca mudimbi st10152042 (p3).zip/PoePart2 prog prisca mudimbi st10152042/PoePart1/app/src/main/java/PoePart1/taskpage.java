/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PoePart1;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


/**
 *
 * @author prisca
 */

public class taskpage {
    private static Scanner scanner = new Scanner(System.in);
    private static List<String> developerList = new ArrayList<String>();
    private static List<String> taskNameList = new ArrayList<String>();
    private static List<String> taskIDList = new ArrayList<String>();
    private static List<Integer> taskDurationList = new ArrayList<Integer>();
    private static List<String> taskStatusList = new ArrayList<String>();
    private static int totalHours;

    public static void main() {
        System.out.println("Welcome to Easy Kanban");
        Login();
        menu();
    }

    private static void Login() {
        String username = JOptionPane.showInputDialog("Enter your username");
        String password = JOptionPane.showInputDialog("Enter your password");
        // Check login credentials and allow access to add tasks
    }

private static void menu() {
    while (true) {
        String[] options = {"Add tasks", "Show report", "Search by task name", "Search by developer",
                "Delete task", "Show task with longest duration", "Quit"};
        String option = (String) JOptionPane.showInputDialog(null, "Select an option:", "Menu", JOptionPane.PLAIN_MESSAGE,
                null, options, options[0]);

        if (option == null) {
            // User clicked cancel or closed the dialog
            break;
        }

        switch (option) {
            case "Add tasks":
                addTasks();
                break;
            case "Show report":
                displayTaskReport();
                break;
            case "Search by task name":
                searchByTaskName();
                break;
            case "Search by developer":
                searchByDeveloper();
                break;
            case "Delete task":
                deleteTask();
                break;
            case "Show task with longest duration":
                displayTaskWithLongestDuration();
                break;
            case "Quit":
                JOptionPane.showMessageDialog(null, "Total hours: " + totalHours);
                System.exit(0);
            default:
                JOptionPane.showMessageDialog(null, "Invalid option, please try again.");
                break;
        }
    }
}

    private static void addTasks() {
        String inputTaskCount = JOptionPane.showInputDialog("How many tasks would you like to enter?");
        int taskCount = Integer.parseInt(inputTaskCount);

        for (int i = 0; i < taskCount; i++) {
            JOptionPane.showMessageDialog(null, "Task " + (i + 1));
            String taskName = JOptionPane.showInputDialog("Enter task name");
            String taskDescription = JOptionPane.showInputDialog("Enter task description (max 50 characters)");

            while (!checkTaskDescription(taskDescription)) {
                JOptionPane.showMessageDialog(null,
                        "Please enter a task description of less than 50 characters");
                taskDescription = JOptionPane.showInputDialog("Enter task description (max 50 characters)");
            }

            String firstName = JOptionPane.showInputDialog("Enter developer's first name");
            String lastName = JOptionPane.showInputDialog("Enter developer's last name");
            String developer = firstName + " " + lastName;
            String taskID = createTaskID(taskName, i, firstName, lastName);
            String inputTaskDuration = JOptionPane.showInputDialog("Enter task duration in hours");

            int taskDuration = Integer.parseInt(inputTaskDuration);
            totalHours += taskDuration;
            String taskStatus = selectTaskStatus();

            developerList.add(developer);
            taskNameList.add(taskName);
            taskIDList.add(taskID);
            taskDurationList.add(taskDuration);
            taskStatusList.add(taskStatus);

            String taskDetails = printTaskDetails(taskStatus, developer, i, taskName, taskDescription, taskID, taskDuration);
            JOptionPane.showMessageDialog(null, taskDetails);
        }
    }

    private static boolean checkTaskDescription(String taskDescription) {
        return taskDescription.length() < 50;
    }

    private static String createTaskID(String taskName, int taskNumber, String firstName, String lastName) {
        String firstTwoLetters = taskName.substring(0, 2).toUpperCase();
        String lastThreeLetters = lastName.substring(0, Math.min(lastName.length(), 3)).toUpperCase();
        return firstTwoLetters + ":" + taskNumber + ":" + lastThreeLetters;
    }

    private static String selectTaskStatus() {
        String[] options = {"To Do", "Doing", "Done"};
        while (true) {
            int statusOption = JOptionPane.showOptionDialog(null, "Select task status:", "Task Status",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
            switch (statusOption) {
                case 0:
                    return "To Do";
                case 1:
                    return "Doing";
                case 2:
                    return "Done";
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option, please try again.");
                    break;
            }
        }
    }

    private static String printTaskDetails(String taskStatus, String developer, int taskNumber, String taskName,
            String taskDescription, String taskID, int taskDuration) {

        return "Task Status: " + taskStatus + "\n" + "Developer: " + developer + "\n" + "Task Number: " + taskNumber
                + "\n" + "Task Name: " + taskName + "\n" + "Task Description: " + taskDescription + "\n" + "Task ID: "
                + taskID + "\n" + "Task Duration: " + taskDuration + " hours\n";
    }

    private static void displayTaskReport() {
        String report = "Task Report:\n";
        for (int i = 0; i < taskIDList.size(); i++) {
            report += "- Task ID: " + taskIDList.get(i) + ", Task Name: " + taskNameList.get(i) + ", Developer: "
                    + developerList.get(i) + ", Duration: " + taskDurationList.get(i) + ", Status: " + taskStatusList.get(i) + "\n";
        }
        JOptionPane.showMessageDialog(null, report);
    }
    
    private static void displayTaskWithLongestDuration() {
        int maxDurationIndex = taskDurationList.indexOf(taskDurationList.stream().max(Comparator.naturalOrder()).get());
        String taskDetails = printTaskDetails(taskStatusList.get(maxDurationIndex), developerList.get(maxDurationIndex), maxDurationIndex, 
            taskNameList.get(maxDurationIndex), "", taskIDList.get(maxDurationIndex), taskDurationList.get(maxDurationIndex));
        JOptionPane.showMessageDialog(null, taskDetails);
    }

    private static void searchByTaskName() {
        String inputTaskName = JOptionPane.showInputDialog("Enter task name to search for:");
        int taskIndex = taskNameList.indexOf(inputTaskName);
        if (taskIndex != -1) {
            String taskDetails = printTaskDetails(taskStatusList.get(taskIndex), developerList.get(taskIndex), taskIndex,
                    taskNameList.get(taskIndex), "", taskIDList.get(taskIndex), taskDurationList.get(taskIndex));
            JOptionPane.showMessageDialog(null, taskDetails);
        } else {
            JOptionPane.showMessageDialog(null, "Task not found.");
        }
    }

    private static void searchByDeveloper() {
        String inputDeveloper = JOptionPane.showInputDialog("Enter developer name to search for:");
        String report = "Tasks assigned to " + inputDeveloper + ":\n";
        for (int i = 0; i < developerList.size(); i++) {
            if (developerList.get(i).equalsIgnoreCase(inputDeveloper)) {
                report += "- Task Name: " + taskNameList.get(i) + ", Status: " + taskStatusList.get(i) + "\n";
            }
        }
        JOptionPane.showMessageDialog(null, report);
    }

    private static void deleteTask() {
        String inputTaskName = JOptionPane.showInputDialog("Enter task name to delete:");
        int taskIndex = taskNameList.indexOf(inputTaskName);
        if (taskIndex != -1) {
            developerList.remove(taskIndex);
            taskNameList.remove(taskIndex);
            taskIDList.remove(taskIndex);
            taskDurationList.remove(taskIndex);
            taskStatusList.remove(taskIndex);
            JOptionPane.showMessageDialog(null, "Task deleted successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "Task not found.");
        }
    }
}
