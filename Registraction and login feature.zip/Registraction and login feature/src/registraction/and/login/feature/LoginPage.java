/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registraction.and.login.feature;
//imprt java.awt.Font.;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;

/**
 * 
 * @author lab_services_student
 */

public class LoginPage implements ActionListener {
    JFrame form  = new JFrame();
    JButton LoginButton = new JButton("login");
    JButton ResetButton = new JButton("Reset");
    JTextField userIDField = new JTextField();
    JPasswordField userPassword = new JPasswordField();
    JLabel userIDLabel = new JLabel("User ID");
    JLabel userPasswordLabel = new JLabel("Password");
    JLabel messageLabel = new JLabel ();
    JButton createAccount = new JButton("Create Account");

  LoginPage(){
        userIDLabel.setBounds(50,100,75,25);
        userPasswordLabel.setBounds(50,150,75,25);
        userIDField.setBounds(125,100,150,25);
        userPassword.setBounds(125,150,150,25);
        messageLabel.setBounds(125,250,250,25);
        //essageLabel.setFont(new Font(nullFont.ITALIC,25));
        
        
       LoginButton.setBounds(125,200,100,25);
       LoginButton.addActionListener(this);
       
       createAccount.setBounds(225,200,100,25);
       createAccount.addActionListener(this);
       
       ResetButton.setBounds(325,200,100,25);
       ResetButton.addActionListener(this);
       
       form.add(userIDLabel);
       form.add(userPasswordLabel);
       form.add(userIDField);
       form.add(userPassword);
       form.add(messageLabel);
       form.add(LoginButton);
       form.add(ResetButton);
       form.add(createAccount);
             
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        form.setSize(420,420);
        form.setLayout(null);
        form.setVisible(true);
        
  }
  

   
  public void actionPerformed(ActionEvent e){
        if(e.getSource()== ResetButton)
        {
            userIDField.setText("");
            userPassword.setText("");
            
        }
        if(e.getSource()== createAccount){
            CreateAccount LoginPage = new CreateAccount();
            form.dispose();
           
        }
        if(e.getSource()==LoginButton){
            String userID = userIDField.getText();
            String Password = String.valueOf(userPassword.getPassword());
            
            
            if(userID.length()<=5 && Password.length()>=8)
            {
                messageLabel.setText("Login Successful");
                form.dispose();
               
           // }else if((userID.length()>5)||(userID.contains)("")){
                
                messageLabel.setText("userID must be less than 5 characters long and not have any space");
            }else{
                messageLabel.setText("Try again");
            }
            Welcome wel = new Welcome( userID);
        }
        }
        }
    
        