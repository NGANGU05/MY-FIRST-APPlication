/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registraction.and.login.feature;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class Welcome {
    JFrame frame = new JFrame();
    JLabel welcomeLabel = new JLabel();
    
    
Welcome(String userName){
    welcomeLabel.setBounds(0, 0, 200, 35);
    welcomeLabel.setFont(new Font(null,Font.PLAIN,25));
    welcomeLabel.setText("Welcome " + userName+ "to EasyKanban ");
    
    frame.add(welcomeLabel);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(420, 420);
    frame.setLayout(null);
    MyApp();
}    
    public static boolean MyApp(){
        
    
        String[] Options = {"Add Task","Show Report (Coming Soon)","Quit"};
        
        int val = JOptionPane.showOptionDialog(null, 
                "Please select an option",
                "Welcome To EasyKanBan", 
                JOptionPane.YES_NO_CANCEL_OPTION, 
                JOptionPane.PLAIN_MESSAGE, null, 
                Options, 
                0);
        System.out.println(val);
        
        while(val!=1){
        if(val ==0){
            
            
            //TaskNum();
            break;
        }
        if(val == 2){
            break;
        }
    }
    
    
    
   //public static boolean TaskNum(){
        String Number = JOptionPane.showInputDialog("Please add number of tasks");
        int x = Integer.parseInt(Number);
        for(int i = 0;i< x ;i++){
            TaskMaker();
                   
        } return true;
        
    }
    
    
    public static boolean TaskMaker(){
        String TaskNam = JOptionPane.showInputDialog("Enter Task Name");
        String TaskNum = JOptionPane.showInputDialog("Enter Task Number");
        ///////////////////////////////////////////////////////////////////////
        //This alllows us to input a task description with a character limit of 50 characters
        String TaskD = JOptionPane.showInputDialog("Task Description"); 
        Pattern P = Pattern.compile("((?=.*[a-z]).{0,50})");
        Matcher M = P.matcher(TaskD);
        if (M.matches()){
            JOptionPane.showMessageDialog(null, "Task successfully caputured");
        }else{
            JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        String DevDetail = JOptionPane.showInputDialog("Developer Details (First and Last Name)");
        String Duration = JOptionPane.showInputDialog("Task Duration (hours)");
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Allows us to select first two letters of task name entered
        String Tn = TaskNam.substring(0,2);
        String Last3 = DevDetail.substring(DevDetail.length() - 3);
        System.out.println(Tn);
         System.out.println(Last3);
         
        JOptionPane.showMessageDialog(null, "Task ID is " + (Tn +":" + TaskNum + ":" + Last3).toUpperCase());
        
        //ID that contains first 2 lessons of Task Name, Task Number, last 3 letters of developer name
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        
        String[] Status = {"To Do","Doing","Done"};
        
        int status = JOptionPane.showOptionDialog(null, 
                "Please select Task Status", 
                "Status", 
                JOptionPane.YES_NO_CANCEL_OPTION, 
                JOptionPane.PLAIN_MESSAGE, 
                null, 
                Status, 
                0);
        //This will be displayed in the following order: Task Status, Developer Details, Task Number, Task Name, Task Description, Task ID and Duration
       //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          
       JOptionPane.showMessageDialog(null, 
               "Task Status: " + status + "\n" + 
               "Developer Details: " + DevDetail + "\n" + 
               "Task Number: " + TaskNum + "\n" + 
               "Task Name: " + TaskNam + "\n" + 
               "Task Description: " + TaskD + "\n" + 
               "Task ID is " +((Tn +":" + TaskNum + ":" + Last3).toUpperCase()) + "\n" +
               "Task Duration: " + Duration + " hours");
        
        
        
        return true;
    }
}

