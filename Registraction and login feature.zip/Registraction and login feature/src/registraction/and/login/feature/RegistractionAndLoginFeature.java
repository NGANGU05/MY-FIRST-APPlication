/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registraction.and.login.feature;

/**
 *
 * @author lab_services_student
 */
public class RegistractionAndLoginFeature {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LoginPage loginForm = new LoginPage();

    }
    
}
