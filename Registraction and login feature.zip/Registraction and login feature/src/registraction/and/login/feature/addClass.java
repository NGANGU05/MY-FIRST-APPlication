/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registraction.and.login.feature;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;



public class addClass {
    
    
    public static boolean checkTaskDescription(){
       
        //This alllows us to input a task description with a character limit of 50 characters
        String TaskD = JOptionPane.showInputDialog("Task Description"); 
        Pattern P = Pattern.compile("((?=.*[a-z]).{0,50})");
        Matcher M = P.matcher(TaskD);
        if (M.matches()){
            JOptionPane.showMessageDialog(null, "Task successfully caputured");
        }else{
            JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
        }
        
        return true;
    }
    
    public static String createTaskID(){
        
        String TaskNam = JOptionPane.showInputDialog("Enter Task Name");
        
        String TaskNum = JOptionPane.showInputDialog("Enter Task Number");
       
        String DevDetail = JOptionPane.showInputDialog("Developer Details (First and Last Name)");
        
        String Tn = TaskNam.substring(0,2);
        String Last3 = DevDetail.substring(DevDetail.length() - 3);
        System.out.println(Tn);
        System.out.println(Last3);
         
        JOptionPane.showMessageDialog(null, "Task ID is " + (Tn +":" + TaskNum + ":" + Last3).toUpperCase());
        
        
        
        
        return  createTaskID();
        
    }
    
    
    public static String printTaskDetails(){
        
        String TaskNam = JOptionPane.showInputDialog("Enter Task Name");
        String TaskNum = JOptionPane.showInputDialog("Enter Task Number");
        ///////////////////////////////////////////////////////////////////////
        //This alllows us to input a task description with a character limit of 50 characters
        String TaskD = JOptionPane.showInputDialog("Task Description"); 
        Pattern P = Pattern.compile("((?=.*[a-z]).{0,50})");
        Matcher M = P.matcher(TaskD);
        if (M.matches()){
            JOptionPane.showMessageDialog(null, "Task successfully caputured");
        }else{
            JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        String DevDetail = JOptionPane.showInputDialog("Developer Details (First and Last Name)");
        String Duration = JOptionPane.showInputDialog("Task Duration (hours)");
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Allows us to select first two letters of task name entered
        String Tn = TaskNam.substring(0,2);
        String Last3 = DevDetail.substring(DevDetail.length() - 3);
        System.out.println(Tn);
         System.out.println(Last3);
         
        JOptionPane.showMessageDialog(null, "Task ID is " + (Tn +":" + TaskNum + ":" + Last3).toUpperCase());
        
        //ID that contains first 2 lessons of Task Name, Task Number, last 3 letters of developer name
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        
        String[] Status = {"To Do","Doing","Done"};
        
        int status = JOptionPane.showOptionDialog(null, 
                "Please select Task Status", 
                "Status", 
                JOptionPane.YES_NO_CANCEL_OPTION, 
                JOptionPane.PLAIN_MESSAGE, 
                null, 
                Status, 
                0);
       
        JOptionPane.showMessageDialog(null, 
               "Task Status: " + status + "\n" + 
               "Developer Details: " + DevDetail + "\n" + 
               "Task Number: " + TaskNum + "\n" + 
               "Task Name: " + TaskNam + "\n" + 
               "Task Description: " + TaskD + "\n" + 
               "Task ID is " +((Tn +":" + TaskNum + ":" + Last3).toUpperCase()) + "\n" +
               "Task Duration: " + Duration + " hours");
        
        return printTaskDetails();
    }
    
    
    public static int returnTotalHours(){
       
        
        
        return returnTotalHours();
    }
    
            
    
}
