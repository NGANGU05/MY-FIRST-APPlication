
package icefour;

import java.util.Scanner;

public class CaitlynsCraftyCreations {

  public static void main(String[] args) {
double costOfMaterials = 0;
double hoursOfWork = 0;
     
RetailPrice( costOfMaterials, hoursOfWork);
      //Scanner object is used to read the values entered by the user.

      Scanner put = new Scanner(System.in);

      //Getting Product Name From the User

      System.out.print("The name of a product :");

      String nameOfProduct=put.nextLine();

     

      //Getting the cost of the material entered by the user.

      System.out.print("The cost of materials : $");

      costOfMaterials=put.nextDouble();

     

      //Getting the Hours of work entered by the user..

      System.out.print("Enter the hours of work :");

      hoursOfWork =put.nextDouble();

     

      /*

      * Calling the method

      * by passing the costOfMeterials and hoursOfWork as parameters.

      * Get the Returned value and stored into a varible of type double.

      */

      double retailPrice= RetailPrice(costOfMaterials,hoursOfWork);

     

      //Displaying the Product name and Its retail price after discount.

      System.out.println("The Name of the Product is :"+nameOfProduct);

      System.out.println("The Retail Price after  is : $"+retailPrice);

         

     

  }

  /*

  * This method will find the retail price of the Product after discount.

  * @Param costOfMaterials,hoursOfWork

  * Return discounted retail price of double type.

  */

  private static double RetailPrice(double costOfMaterials,double hoursOfWork)

  {

      return  (costOfMaterials + (12* hoursOfWork)) + 7 ;

  }

}

