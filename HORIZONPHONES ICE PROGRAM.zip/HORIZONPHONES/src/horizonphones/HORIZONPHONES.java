
package horizonphones;

import java.util.Scanner;

import java.util.Scanner;

public class HORIZONPHONES {
    public static void main(String[] args) {
        int minutes,message,gigabytes,data = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("enter talk  minutes used : ");
        minutes = sc.nextInt();

        System.out.print("enter  text messages : ");
        message = sc.nextInt();
        System.out.print("enter gigabytes of  data used : ");
        gigabytes = sc.nextInt();

        if(minutes<500 && message == 0 && data == 0)System.out.println("Plan A, 49$ per month");
   

        if(minutes<500 && message > 0 && data == 0)System.out.println("Plan B, 55$ per month");
        if(minutes>=500 && data == 0 && message <=100 && message<=100)System.out.println("Plan C, 61$ per month");
        if(minutes>=500 && gigabytes== 0 && message >=100)System.out.println("Plan D, 70$ per month");
        if (gigabytes>0 && gigabytes <2) System.out.println("Plan E, 79$ per month");
        if (gigabytes>0 && gigabytes >=2) System.out.println("Plan F, 87$ per month");
    
        sc.close();
        
    
    } 
    
}

